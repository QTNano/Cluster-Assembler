import ase.neighborlist as ase_n
# from ase import NeighborList, neighbor_list
# from ase import geometry
# from ase.build import molecule
from ase.io import read
from scipy import sparse
import glob
import shutil
import tqdm
import numpy as np

def integrity_test(folder: str, threshold: float):
    files=glob.glob(folder+"/unfiltered/*.xyz")
    folder_out = folder+"/filtered"

    for file in tqdm.tqdm(files):
            mol=read(file)
            cutOff = ase_n.natural_cutoffs(mol)
            # print("DEBUG: Check cutoff at connectivity")
            cutOff = [dist*threshold for dist in cutOff]
            neighborList = ase_n.NeighborList(cutOff, self_interaction=False, bothways=True)
            neighborList.update(mol)
            matrix = neighborList.get_connectivity_matrix(sparse=False)
            n_components, component_list = sparse.csgraph.connected_components(matrix)

            if n_components==1:
                    shutil.copy(file,folder_out+"/"+file.split("/")[-1])
                # # i, j, d = ase_n.neighbor_list('ijd', mol, 1.5)
                # d = ase_n.neighbor_list('d', mol, 0.7)
                # if len(d) == 0:
                #     shutil.copy(file,folder_out+"/"+file.split("/")[-1])


def integrity_test_complexes(folder: str, threshold: float):
    files=glob.glob(folder+"/unfiltered/*.xyz")
    folder_out = folder+"/filtered"

    for file in tqdm.tqdm(files):
            # print("="*20)
            # print("FILE: ", file)
            mol=read(file)
            cutOff = ase_n.natural_cutoffs(mol)
            rmax = np.max(cutOff)
            i, j, d = ase_n.neighbor_list('ijd', mol, rmax*2.0)
            file_ok = True
            for index_i, index_j, dist in zip(i, j, d):
                # if index_i in [3,4,5]:
                #     print(f"{index_i}:{index_j} - {cutOff[index_i]}+{cutOff[index_j]} -> {dist:.2f} Å")
                if dist*threshold < (cutOff[index_i]+cutOff[index_j]):
                      file_ok = False
                      break
            if file_ok:
                shutil.copy(file,folder_out+"/"+file.split("/")[-1])
